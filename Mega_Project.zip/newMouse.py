import cv2
import numpy as np
import time
import pyautogui
import HandTracking as ht
import autopy

# Variables Declaration
pTime = 0
width, height = 640, 480
frameR = 100
smoothening = 8
prev_x, prev_y = 0, 0
curr_x, curr_y = 0, 0

cap = cv2.VideoCapture(0)
cap.set(3, width)
cap.set(4, height)

detector = ht.handDetector(maxHands=1)
screen_width, screen_height = autopy.screen.size()

while True:
    success, img = cap.read()
    img = detector.findHands(img)
    lmlist, bbox = detector.findPosition(img)

    if len(lmlist) != 0:
        x1, y1 = lmlist[8][1:]
        x2, y2 = lmlist[12][1:]

        fingers = detector.fingersUp()
        cv2.rectangle(img, (frameR, frameR), (width - frameR, height - frameR), (255, 0, 255), 2)

        if fingers[1] == 1 and fingers[2] == 0:  # If forefinger is up and middle finger is down
            x3 = np.interp(x1, (frameR, width - frameR), (0, screen_width))
            y3 = np.interp(y1, (frameR, height - frameR), (0, screen_height))

            curr_x = prev_x + (x3 - prev_x) / smoothening
            curr_y = prev_y + (y3 - prev_y) / smoothening

            autopy.mouse.move(screen_width - curr_x, curr_y)
            cv2.circle(img, (x1, y1), 7, (255, 0, 255), cv2.FILLED)
            prev_x, prev_y = curr_x, curr_y

        elif fingers[0] == 1 and fingers[2] == 1:  # If thumb and middle finger are up
            autopy.mouse.click(autopy.mouse.Button.RIGHT)  # Perform Right Click

        elif fingers[1] == 1 and fingers[2] == 1:  # If forefinger & middle finger both are up
            length, img, lineInfo = detector.findDistance(8, 12, img)

            if length < 70:  # If both fingers are really close to each other
                cv2.circle(img, (lineInfo[4], lineInfo[5]), 15, (0, 255, 0), cv2.FILLED)
                autopy.mouse.click()  # Perform Left Click

        elif fingers[0] == 0 and fingers[1] == 0 and fingers[2] == 0 and fingers[3] == 0 and fingers[4] == 1:  # If all fingers except index finger are up
            autopy.mouse.toggle(autopy.mouse.Button.LEFT, True)  # Start dragging

        if fingers[0] == 0 and fingers[1] == 0 and fingers[2] == 1:  # If thumb is up and index finger is down
            pyautogui.scroll(50)  # Scroll up
        elif fingers[0] == 1 and fingers[1] == 0 and fingers[2] == 0:  # If thumb is down and index finger is up
            pyautogui.scroll(-50)  # Scroll down

    else:
        autopy.mouse.toggle(autopy.mouse.Button.LEFT, False)  # Stop dragging if no fingers detected

    cTime = time.time()
    fps = 1 / (cTime - pTime)
    pTime = cTime
    cv2.putText(img, str(int(fps)), (20, 50), cv2.FONT_HERSHEY_PLAIN, 3, (255, 0, 0), 3)
    cv2.imshow("Image", img)
    cv2.waitKey(1)
